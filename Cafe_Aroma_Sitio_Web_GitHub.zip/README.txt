CAFÉ AROMA - SITIO WEB ESCOLAR

Archivos:
- index.html: página inicial
- menu.html: menú de productos
- contacto.html: contacto con exactamente cinco botones
- styles.css: diseño y adaptación a móviles

PUBLICAR GRATIS CON GITHUB PAGES:
1. Entra a https://github.com e inicia sesión.
2. Crea un repositorio nuevo llamado cafe-aroma-web.
3. Selecciona Public (público) y crea el repositorio.
4. En el repositorio, selecciona Add file > Upload files.
5. Sube TODOS los archivos de esta carpeta (index.html, menu.html, contacto.html y styles.css).
6. Presiona Commit changes.
7. Abre Settings > Pages.
8. En Build and deployment, selecciona Deploy from a branch.
9. Selecciona la rama main y la carpeta /(root), y presiona Save.
10. Espera a que termine la publicación. La URL tendrá esta forma:
   https://TU-USUARIO.github.io/cafe-aroma-web/

IMPORTANTE:
- Cambia TU-USUARIO por tu nombre de usuario de GitHub.
- La publicación puede tardar unos minutos.
- GitHub Pages publica el sitio en internet; el repositorio público permite usarlo con GitHub Free.
- Los datos de WhatsApp, correo y redes de contacto son ejemplos. Reemplázalos por datos reales o déjalos como demostración escolar.
- No se adjuntó un archivo de código de "Recursos" en esta conversación; este proyecto se elaboró desde cero con HTML y CSS.
